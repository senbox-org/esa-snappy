# Created by 'jpyutil.py' tool on 2022-10-06 01:34:13.267262
# This file is read by the 'jpyutil' module in order to load and configure the JVM from Python
java_home = '/home/olafd/java/jdk1.8.0_333/'
jvm_dll = '/home/olafd/java/jdk1.8.0_333/jre/lib/amd64/server/libjvm.so'
jvm_maxmem = None
jvm_classpath = []
jvm_properties = {}
jvm_options = []
