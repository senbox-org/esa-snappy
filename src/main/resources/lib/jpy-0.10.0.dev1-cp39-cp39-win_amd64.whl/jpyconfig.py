# Created by 'jpyutil.py' tool on 2022-10-06 00:50:53.599364
# This file is read by the 'jpyutil' module in order to load and configure the JVM from Python
java_home = 'C:\\Program Files\\Java\\jdk1.8.0_181'
jvm_dll = 'C:\\Program Files\\Java\\jdk1.8.0_181\\jre\\bin\\server\\jvm.dll'
jvm_maxmem = None
jvm_classpath = []
jvm_properties = {}
jvm_options = []
